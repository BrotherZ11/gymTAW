package com.example.gymtaw.ui;

public class Filtro {
    private int idRol;

    public Filtro(){

    }

    public int getIdRol() {
        return idRol;
    }

    public void setIdRol(int nombreRol) {
        this.idRol = nombreRol;
    }
}
