package com.example.gymtaw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GymTawApplication {

	public static void main(String[] args) {
		SpringApplication.run(GymTawApplication.class, args);
	}

}
