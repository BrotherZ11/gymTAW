package com.example.gymtaw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymTawApplicationTests {

	@Test
	void contextLoads() {
	}

}
